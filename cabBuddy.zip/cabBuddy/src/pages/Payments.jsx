import React from 'react'

function Payments() {
  return (
   <>
    <div className='place-items-center'>
             <img className='mt-1' src="/assets/pic4.svg" alt="" />
             <div className='  text-3xl text-shadow-blue-100 font-semibold'>Looks like you haven't made any online payments yet...</div>
    </div>
   </>
  )
}

export default Payments