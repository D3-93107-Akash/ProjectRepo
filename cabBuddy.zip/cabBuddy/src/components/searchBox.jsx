"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { format } from "date-fns";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";


export default function SearchBox() {
  const[leaveFrom,setLeaveFrom] = useState("")
  const[goingTo,setGoingTo] = useState("")
  const navigate = useNavigate();

  const [date, setDate] = useState(new Date());
  const [passengers, setPassengers] = useState(1);


  const searchHandle=()=>{
    if (leaveFrom !== "" && goingTo !== "") {
       navigate("/search")
    }
    else{
      toast.warn("All fields are compulsory!!");
    }
  }

  return (
    <div className="w-full flex justify-center mt-4">
      
      <div className="w-[95%] md:w-[75%] 
                      flex flex-col md:flex-row 
                      bg-white rounded-2xl shadow-xl overflow-hidden">

       
        <div className="flex items-center gap-2 px-4 py-4 flex-1 border-b md:border-b-0 md:border-r hover:bg-gray-100 cursor-pointer transition">
          <MapPin className="h-5 w-5 text-gray-600" />
          <Input
            value={leaveFrom}
            onChange={(e) => setLeaveFrom(e.target.value)}
            placeholder="Leaving from"
            className="border-none shadow-none focus-visible:ring-0 p-0"
          />
        </div>

   
        <div className="flex items-center gap-2 px-4 py-4 flex-1 border-b md:border-b-0 md:border-r hover:bg-gray-100 cursor-pointer transition">
          <MapPin className="h-5 w-5 text-gray-600" />
          <Input
            value={goingTo}
            onChange={(e) => setGoingTo(e.target.value)}
            placeholder="Going to"
            className="border-none shadow-none focus-visible:ring-0 p-0"
          />
        </div>

       
        <Popover>
          <PopoverTrigger asChild>
            <div className="flex items-center gap-2 px-4 py-4 flex-1 border-b md:border-b-0 md:border-r cursor-pointer hover:bg-gray-100 transition">
              <CalendarDays className="h-5 w-5 text-gray-600" />
              <span className="text-gray-700">
                {format(date, "dd MMM yyyy")}
              </span>
            </div>
          </PopoverTrigger>

          <PopoverContent className="p-0 bg-white ">
            <Calendar
              mode="single"
              selected={date}
              onSelect={(d) => d && setDate(d)}
              initialFocus
              disabled={{ before: new Date() }}
            />
          </PopoverContent>
        </Popover>

        <Popover>
          <PopoverTrigger asChild>
            <div className="flex items-center gap-2 px-4 py-4 flex-1 border-b md:border-b-0 md:border-r cursor-pointer hover:bg-gray-100 transition">
              <Users className="h-5 w-5 text-gray-600" />
              <span className="text-gray-700">
                {passengers} Passenger{passengers > 1 ? "s" : ""}
              </span>
            </div>
          </PopoverTrigger>

          <PopoverContent className="w-40 p-4 bg-white">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setPassengers((p) => Math.max(1, p - 1))}
              >
                −
              </Button>

              <span className="text-lg font-semibold">{passengers}</span>

              <Button
                variant="outline"
                size="icon"
                onClick={() => setPassengers((p) => Math.min(8, p + 1))}
              >
                +
              </Button>
            </div>
          </PopoverContent>
        </Popover>

    
        <Button 
        onClick={searchHandle}
        className="bg-[#00AFFF] text-white font-semibold 
                           w-full md:w-[130px] 
                           text-lg rounded-none h-full 
                           cursor-pointer hover:bg-[#0095db] transition">
          Search
        </Button>

      </div>
    </div>
  );
}
