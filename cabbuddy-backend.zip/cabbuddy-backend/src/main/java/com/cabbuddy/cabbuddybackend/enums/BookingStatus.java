package com.cabbuddy.cabbuddybackend.enums;

public enum BookingStatus {
	 CONFIRMED,
	 CANCELLED
}
