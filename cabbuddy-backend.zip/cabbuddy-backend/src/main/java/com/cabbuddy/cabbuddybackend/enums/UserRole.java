package com.cabbuddy.cabbuddybackend.enums;

public enum UserRole {
	  USER,
	  DRIVER,
	  ADMIN
}
