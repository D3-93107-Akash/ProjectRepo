package com.cabbuddy.cabbuddybackend.exception;

public class UnauthorizedException {

}
