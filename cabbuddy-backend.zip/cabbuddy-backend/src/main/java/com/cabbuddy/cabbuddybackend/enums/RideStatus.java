package com.cabbuddy.cabbuddybackend.enums;

public enum RideStatus {
	ACTIVE,
    CANCELLED,
    COMPLETED
}
